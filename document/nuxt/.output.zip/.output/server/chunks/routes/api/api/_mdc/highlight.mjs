import { d as defineEventHandler } from '../../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';
import 'better-sqlite3';

const highlight = defineEventHandler((event) => {
  return "Hello /api/_mdc/highlight";
});

export { highlight as default };
//# sourceMappingURL=highlight.mjs.map
