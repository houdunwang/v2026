import{bq as e,bm as o}from"./BSLQyFS1.js";import{u as a}from"./B7LL2Jc4.js";const f=e((r,s)=>{const{isLogin:t}=a();if(t.value)return o("/")});export{f as default};
