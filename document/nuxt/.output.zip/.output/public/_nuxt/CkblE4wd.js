import{ax as a}from"./BSLQyFS1.js";function o(r,u="reka"){return r||`${u}-${a?.()}`}export{o as u};
