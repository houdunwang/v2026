import{bY as e,r as o,g as i}from"./BSLQyFS1.js";function u(r){const t=e({dir:o("ltr")});return i(()=>r?.value||t.dir?.value||"ltr")}export{u};
